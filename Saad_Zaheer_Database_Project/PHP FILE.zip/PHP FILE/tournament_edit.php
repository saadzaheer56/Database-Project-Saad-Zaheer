<?php
include "db.php";

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM Tournament WHERE tournament_id='$id'");
$row = mysqli_fetch_assoc($result);

if (isset($_POST['update'])) {
    $location = $_POST['location'];
    $start = $_POST['start_date'];
    $end = $_POST['end_date'];

    mysqli_query($conn, "UPDATE Tournament 
        SET location='$location', start_date='$start', end_date='$end' 
        WHERE tournament_id='$id'");

    header("Location: tournament_view.php");
}
?>

<h2>Edit Tournament</h2>
<form method="post">
    Location: <input type="text" name="location" value="<?php echo $row['location']; ?>"><br><br>
    Start Date: <input type="date" name="start_date" value="<?php echo $row['start_date']; ?>"><br><br>
    End Date: <input type="date" name="end_date" value="<?php echo $row['end_date']; ?>"><br><br>
    <button name="update">Update</button>
</form>
