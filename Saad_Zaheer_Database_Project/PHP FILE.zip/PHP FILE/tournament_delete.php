<?php
include "db.php";

$id = $_GET['id'];
mysqli_query($conn, "DELETE FROM Tournament WHERE tournament_id='$id'");

header("Location: tournament_view.php");
?>
