<h2>Sports Tournament Management</h2>
<ul>
    <li><a href="tournament_view.php">Manage Tournaments</a></li>
</ul>
