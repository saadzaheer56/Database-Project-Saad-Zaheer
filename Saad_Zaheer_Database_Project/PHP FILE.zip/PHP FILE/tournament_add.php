<?php
include "db.php";

if (isset($_POST['submit'])) {
    mysqli_query($conn, "INSERT INTO Tournament VALUES (
        '$_POST[tournament_id]',
        '$_POST[location]',
        '$_POST[start_date]',
        '$_POST[end_date]'
    )");
    header("Location: tournament_view.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Tournament</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<div class="container">
    <h2>➕ Add Tournament</h2>

    <form method="post">
        <input type="number" name="tournament_id" placeholder="Tournament ID" required>
        <input type="text" name="location" placeholder="Location" required>
        <input type="date" name="start_date" required>
        <input type="date" name="end_date" required>
        <button type="submit" name="submit">Insert</button>
    </form>
</div>

</body>
</html>
