<?php
include "db.php";
$result = mysqli_query($conn, "SELECT * FROM Tournament");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tournament Management</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<div class="container">
    <h1>🏏 Cricket Tournament Management System</h1>
<p style="text-align:center; font-weight:bold;">
    Manage Matches • Teams • Players • Officials
</p>


    <a href="tournament_add.php" class="btn">➕ Add Tournament</a>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Location</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
            <tr>
                <td><?php echo $row['tournament_id']; ?></td>
                <td><?php echo $row['location']; ?></td>
                <td><?php echo $row['start_date']; ?></td>
                <td><?php echo $row['end_date']; ?></td>
                <td class="action">
                    <a href="tournament_edit.php?id=<?php echo $row['tournament_id']; ?>">✏ Edit</a>
                    <a href="tournament_delete.php?id=<?php echo $row['tournament_id']; ?>" 
                       onclick="return confirm('Are you sure?')">🗑 Delete</a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</div>

</body>
</html>
