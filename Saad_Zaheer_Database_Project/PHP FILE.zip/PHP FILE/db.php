<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "sports_tournament";
$port = 3307;   // ADD THIS LINE

$conn = mysqli_connect($host, $user, $pass, $db, $port);

if (!$conn) {
    die("Connection Failed: " . mysqli_connect_error());
}
?>
